import { int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Webhook events table for capturing BotSpace webhook payloads
 */
export const webhookEvents = mysqlTable("webhookEvents", {
  id: varchar("id", { length: 64 }).primaryKey(),
  channelId: varchar("channelId", { length: 64 }).notNull(),
  workspaceId: varchar("workspaceId", { length: 64 }).notNull(),
  direction: mysqlEnum("direction", ["incoming", "outgoing"]).notNull(),
  eventType: varchar("eventType", { length: 64 }).notNull(), // message-event, delivery-event, etc.
  customerName: text("customerName"),
  customerId: varchar("customerId", { length: 64 }),
  countryCode: varchar("countryCode", { length: 10 }),
  phone: varchar("phone", { length: 20 }).notNull(),
  payload: json("payload").notNull(), // Full JSON payload
  createdOn: timestamp("createdOn").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WebhookEvent = typeof webhookEvents.$inferSelect;
export type InsertWebhookEvent = typeof webhookEvents.$inferInsert;