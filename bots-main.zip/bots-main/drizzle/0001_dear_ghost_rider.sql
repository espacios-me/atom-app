CREATE TABLE `webhookEvents` (
	`id` varchar(64) NOT NULL,
	`channelId` varchar(64) NOT NULL,
	`workspaceId` varchar(64) NOT NULL,
	`direction` enum('incoming','outgoing') NOT NULL,
	`eventType` varchar(64) NOT NULL,
	`customerName` text,
	`customerId` varchar(64),
	`countryCode` varchar(10),
	`phone` varchar(20) NOT NULL,
	`payload` json NOT NULL,
	`createdOn` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `webhookEvents_id` PRIMARY KEY(`id`)
);
