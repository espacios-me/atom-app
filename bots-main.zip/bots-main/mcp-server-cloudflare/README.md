# Cloudflare MCP Server

This is a minimal MCP server designed to run on Cloudflare Workers.

## Features

- MCP over HTTP JSON-RPC at `POST /mcp`
- Built-in tools:
  - `health_check`
  - `echo`

## Local development

```bash
cd mcp-server-cloudflare
npx wrangler dev
```

## Deploy to Cloudflare

```bash
cd mcp-server-cloudflare
npx wrangler deploy
```

If you're not logged in yet:

```bash
npx wrangler login
```

## Quick test

```bash
curl -s http://127.0.0.1:8787/mcp \
  -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | jq
```
