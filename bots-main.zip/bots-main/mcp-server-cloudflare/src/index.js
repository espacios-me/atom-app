const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

function jsonRpcResult(id, result) {
  return {
    jsonrpc: "2.0",
    id,
    result,
  };
}

function jsonRpcError(id, code, message, data) {
  return {
    jsonrpc: "2.0",
    id,
    error: {
      code,
      message,
      ...(data !== undefined ? { data } : {}),
    },
  };
}

async function handleMcpRequest(body) {
  const { id = null, method, params = {} } = body ?? {};

  if (!method || typeof method !== "string") {
    return jsonRpcError(id, -32600, "Invalid Request");
  }

  switch (method) {
    case "initialize":
      return jsonRpcResult(id, {
        protocolVersion: "2025-03-26",
        capabilities: {
          tools: {
            listChanged: false,
          },
        },
        serverInfo: {
          name: "cloudflare-mcp-server",
          version: "1.0.0",
        },
      });

    case "notifications/initialized":
      return null;

    case "tools/list":
      return jsonRpcResult(id, {
        tools: [
          {
            name: "health_check",
            description: "Returns a basic status payload from the Cloudflare MCP server.",
            inputSchema: {
              type: "object",
              properties: {},
              additionalProperties: false,
            },
          },
          {
            name: "echo",
            description: "Echoes a message back to the caller.",
            inputSchema: {
              type: "object",
              properties: {
                message: {
                  type: "string",
                  description: "Message to echo",
                },
              },
              required: ["message"],
              additionalProperties: false,
            },
          },
        ],
      });

    case "tools/call": {
      const toolName = params?.name;
      const args = params?.arguments ?? {};

      if (toolName === "health_check") {
        return jsonRpcResult(id, {
          content: [
            {
              type: "text",
              text: JSON.stringify({
                ok: true,
                timestamp: new Date().toISOString(),
                runtime: "cloudflare-workers",
              }),
            },
          ],
        });
      }

      if (toolName === "echo") {
        if (typeof args.message !== "string") {
          return jsonRpcError(id, -32602, "Invalid params", {
            expected: { message: "string" },
          });
        }

        return jsonRpcResult(id, {
          content: [
            {
              type: "text",
              text: args.message,
            },
          ],
        });
      }

      return jsonRpcError(id, -32601, `Unknown tool: ${toolName}`);
    }

    default:
      return jsonRpcError(id, -32601, `Method not found: ${method}`);
  }
}

export default {
  async fetch(request) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/") {
      return new Response(
        JSON.stringify({
          name: "cloudflare-mcp-server",
          endpoint: "/mcp",
          transport: "HTTP JSON-RPC",
        }),
        { status: 200, headers: JSON_HEADERS },
      );
    }

    if (request.method === "POST" && url.pathname === "/mcp") {
      let body;
      try {
        body = await request.json();
      } catch {
        return new Response(
          JSON.stringify(jsonRpcError(null, -32700, "Parse error")),
          { status: 400, headers: JSON_HEADERS },
        );
      }

      const payload = await handleMcpRequest(body);
      if (payload === null) {
        return new Response(null, { status: 204 });
      }

      return new Response(JSON.stringify(payload), {
        status: 200,
        headers: JSON_HEADERS,
      });
    }

    return new Response(JSON.stringify({ error: "Not Found" }), {
      status: 404,
      headers: JSON_HEADERS,
    });
  },
};
