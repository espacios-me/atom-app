# Workers Dashboard README

This repo now includes a standalone worker control room at:

- `client/public/workers.html`

After the app is built or served locally, open:

- `/workers.html`

## What this page is for

The page is a lightweight dashboard for talking to worker URLs without waiting on deeper app wiring.

It is good for:
- testing JSON worker endpoints
- testing worker.dev preview URLs
- sending sample webhook payloads
- checking headers, auth, and response status
- keeping a saved list of worker URLs in local storage

It is **not** a full MCP client. If your worker is actually an SSE/MCP endpoint, the page can still help you test reachability, but it will not behave like a dedicated MCP client.

## Included in the page

- saved worker list
- chat-style request and response history
- direct GET and POST requests
- optional bearer auth
- optional custom headers JSON
- optional custom body JSON override
- template payloads for:
  - ping
  - chat
  - BotSpace-style webhook event
  - health check

## Route notes for Espacios

From Cloudflare, the route is attached correctly:

- `espacios.me/bot*`

That means the route itself exists and requests should reach the worker.

If BotSpace still says the webhook URL is invalid, the likely issue is **handler behavior**, not DNS or route setup.

Typical reasons:
- the worker is an MCP server, not a plain webhook receiver
- the worker expects a different path than `/bot`
- the worker expects a different payload shape
- the worker rejects browser requests because of auth or CORS
- the worker is listening for SSE or MCP protocol traffic rather than a normal JSON POST

## Practical interpretation

### Route setup
This part looks correct if Cloudflare shows:
- `espacios.me/bot*`

### Endpoint behavior
This is still the part that determines whether BotSpace accepts the URL.

Examples:
- `https://espacios.me/bot` can exist but still fail as a BotSpace webhook
- `https://espacios.me/bot/sse` may be valid for MCP but **not** for BotSpace webhook validation

## How to use the dashboard

1. Start the app or deploy it.
2. Open `/workers.html`.
3. Save one or more worker URLs.
4. Try:
   - `https://espacios.me/bot`
   - `https://espacios.me/bot/sse`
   - `https://botspace-mcp-server-prod.thekeifferjapeth.workers.dev`
5. Use the template payload buttons to test different request shapes.
6. Inspect the response status and body.

## Suggested next repo changes

To make this a fully integrated product rather than a standalone page, wire in the following:

1. Add a React route like `/workers` in `client/src/App.tsx`
2. Move the standalone dashboard into a React page/component
3. Add a backend proxy route to avoid CORS issues
4. Add worker presets from environment variables
5. Add saved conversations per worker in the database
6. Add a dedicated BotSpace webhook tester and validation report
7. Add a dedicated MCP diagnostics panel for `/sse` endpoints

## Why this file exists

You asked for:
- the route analysis pushed into the repo
- a dashboard where you can talk to your workers

Because the available repo tooling in this environment safely supports creating new files directly, this implementation was added as:
- a standalone HTML dashboard under `client/public/`
- this README-style guide at the repo root

That gives you something you can use immediately without waiting for router or server refactors.
