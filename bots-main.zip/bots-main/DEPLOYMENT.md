# Deployment Guide - BotSpace Webhook Monitor

This guide covers deploying the BotSpace webhook monitor to production, specifically for Guilds CRM integration.

## Pre-Deployment Checklist

- [ ] All tests passing (`pnpm test`)
- [ ] No TypeScript errors (`pnpm check`)
- [ ] Environment variables configured
- [ ] Database created and accessible
- [ ] BotSpace webhook URL configured
- [ ] Guilds CRM webhook endpoint available
- [ ] Git repository initialized

## Deployment Options

### Option 1: Guilds CRM Hosting (Recommended)

If Guilds CRM provides hosting infrastructure:

1. **Push to Guilds CRM Git**
   ```bash
   git remote add guilds <guilds-crm-git-url>
   git push guilds main
   ```

2. **Configure Environment Variables** in Guilds CRM dashboard:
   - `DATABASE_URL`
   - `BOTSPACE_API_KEY`
   - `GUILDS_CRM_WEBHOOK_URL`
   - `GUILDS_CRM_API_KEY`
   - `GEMINI_API_KEY` (optional)
   - All OAuth variables

3. **Deploy** via Guilds CRM dashboard or CI/CD pipeline

### Option 2: Railway

Railway provides easy Node.js hosting with MySQL support.

1. **Create Railway project**
   ```bash
   railway init
   ```

2. **Add MySQL plugin** in Railway dashboard

3. **Set environment variables** in Railway dashboard

4. **Deploy**
   ```bash
   railway up
   ```

### Option 3: Render

Render offers free tier with PostgreSQL (requires schema adaptation).

1. **Connect GitHub repository** to Render

2. **Create Web Service** with Node.js environment

3. **Add PostgreSQL database** (requires schema changes)

4. **Set environment variables** in Render dashboard

5. **Deploy** automatically on git push

### Option 4: Heroku

Heroku provides simple deployment with add-ons.

1. **Create Heroku app**
   ```bash
   heroku create your-app-name
   ```

2. **Add MySQL add-on**
   ```bash
   heroku addons:create cleardb:ignite
   ```

3. **Set environment variables**
   ```bash
   heroku config:set BOTSPACE_API_KEY=your_key
   heroku config:set GUILDS_CRM_WEBHOOK_URL=your_url
   # ... set all other variables
   ```

4. **Deploy**
   ```bash
   git push heroku main
   ```

## Post-Deployment Steps

### 1. Verify Database

```bash
# Connect to your production database
mysql -h your-host -u your-user -p your-database

# Check tables exist
SHOW TABLES;
DESC webhookEvents;
```

### 2. Test Webhook Endpoint

```bash
curl -X POST https://your-domain.com/api/trpc/webhook.receive \
  -H "Content-Type: application/json" \
  -d '{
    "id": "test-123",
    "channelId": "channel-456",
    "workspaceId": "workspace-789",
    "direction": "incoming",
    "event": "message-event",
    "createdOn": "2026-03-28T08:00:00Z",
    "customer": {"name": "Test User", "id": "user-123"},
    "phone": {"countryCode": "1", "phone": "5551234567"},
    "payload": {"type": "text", "payload": {"text": "Test message"}}
  }'
```

Expected response:
```json
{
  "success": true,
  "eventId": "test-123",
  "message": "Event captured and forwarded"
}
```

### 3. Configure BotSpace Webhook

In BotSpace dashboard:

1. Go to **Settings → Webhooks**
2. Add webhook endpoint: `https://your-domain.com/api/trpc/webhook.receive`
3. Select event types: Incoming Messages, Outgoing Messages, Delivery Events
4. Save and test

### 4. Verify Guilds CRM Forwarding

1. Send a test message through BotSpace
2. Check your production logs for `[Webhook Forwarder]` entries
3. Verify event appears in Guilds CRM
4. Check dashboard at `https://your-domain.com/dashboard`

## Monitoring & Maintenance

### View Logs

**Railway**:
```bash
railway logs
```

**Render**:
```bash
render logs
```

**Heroku**:
```bash
heroku logs --tail
```

### Common Issues

#### Database Connection Failed
- Verify `DATABASE_URL` is correct
- Check database server is accessible
- Ensure firewall allows connections

#### Webhook Events Not Appearing
- Verify webhook URL in BotSpace settings
- Check server logs for errors
- Test endpoint with curl

#### Guilds CRM Forwarding Failing
- Verify `GUILDS_CRM_WEBHOOK_URL` is correct
- Check `GUILDS_CRM_API_KEY` is valid
- Look for `[Webhook Forwarder]` error logs
- Test API key with curl

#### Dashboard Not Loading
- Check OAuth configuration
- Verify `VITE_APP_ID` and `OAUTH_SERVER_URL`
- Check browser console for errors

### Scaling Considerations

**For high-volume webhooks** (1000+ events/day):

1. **Enable database connection pooling**
   - Use `mysql2/promise` with connection pool
   - Adjust pool size based on load

2. **Add caching layer**
   - Cache event counts and statistics
   - Invalidate on new events

3. **Implement message queuing**
   - Use Redis or RabbitMQ for webhook processing
   - Process events asynchronously

4. **Database optimization**
   - Add indexes on `createdOn`, `phone`, `customerName`
   - Archive old events to separate table

## Rollback Procedure

If deployment fails:

1. **Identify issue** from logs
2. **Revert to previous version**
   ```bash
   git revert HEAD
   git push
   ```
3. **Redeploy** using your platform's tools
4. **Verify** webhook endpoint is working

## Security Best Practices

1. **Never commit secrets** - use environment variables
2. **Use HTTPS only** - ensure webhook URL uses https://
3. **Validate webhook payloads** - verify BotSpace signature (when available)
4. **Rotate API keys** - periodically update credentials
5. **Monitor access logs** - watch for suspicious activity
6. **Use strong database passwords** - follow security guidelines
7. **Enable database SSL** - encrypt database connections

## Performance Optimization

### Database Queries
- Add indexes on frequently searched columns
- Use pagination for large result sets
- Archive old events periodically

### API Response Times
- Cache event counts (refresh every 5 seconds)
- Use database connection pooling
- Implement CDN for static assets

### Webhook Processing
- Process forwarding asynchronously
- Implement retry logic with exponential backoff
- Log all attempts for debugging

## Backup & Recovery

### Database Backups

**Automated backups** (recommended):
- Most hosting platforms offer automated daily backups
- Configure retention policy (e.g., 30 days)

**Manual backups**:
```bash
# MySQL
mysqldump -h your-host -u your-user -p your-database > backup.sql

# Restore
mysql -h your-host -u your-user -p your-database < backup.sql
```

### Code Backups

Git automatically maintains version history:
```bash
# View commit history
git log

# Restore specific version
git checkout <commit-hash>
```

## Support

For deployment issues:

1. Check application logs
2. Review this guide's troubleshooting section
3. Consult hosting platform documentation
4. Contact Guilds CRM support

## Next Steps

After successful deployment:

1. Monitor webhook events in dashboard
2. Verify Guilds CRM integration is working
3. Set up alerts for errors
4. Plan for scaling if needed
5. Consider adding Google Drive and Gmail sync
