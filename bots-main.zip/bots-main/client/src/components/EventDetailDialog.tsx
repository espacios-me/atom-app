import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { WebhookEvent } from "../../../drizzle/schema";

interface EventDetailDialogProps {
  event: WebhookEvent;
  isOpen: boolean;
  onClose: () => void;
}

export function EventDetailDialog({ event, isOpen, onClose }: EventDetailDialogProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyPayload = () => {
    const jsonString = JSON.stringify(event.payload, null, 2);
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyFullEvent = () => {
    const fullEvent = {
      id: event.id,
      channelId: event.channelId,
      workspaceId: event.workspaceId,
      direction: event.direction,
      eventType: event.eventType,
      customerName: event.customerName,
      customerId: event.customerId,
      phone: event.phone,
      countryCode: event.countryCode,
      createdOn: event.createdOn,
      payload: event.payload,
    };
    navigator.clipboard.writeText(JSON.stringify(fullEvent, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Event Details - {event.id}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Event Metadata */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold text-foreground">Channel ID</label>
              <p className="text-sm text-muted-foreground break-all">{event.channelId}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground">Workspace ID</label>
              <p className="text-sm text-muted-foreground break-all">{event.workspaceId}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground">Direction</label>
              <p className="text-sm text-muted-foreground">{event.direction}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground">Event Type</label>
              <p className="text-sm text-muted-foreground">{event.eventType}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground">Customer Name</label>
              <p className="text-sm text-muted-foreground">{event.customerName || "N/A"}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground">Customer ID</label>
              <p className="text-sm text-muted-foreground break-all">{event.customerId || "N/A"}</p>
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground">Phone</label>
              <p className="text-sm text-muted-foreground">
                {event.countryCode && `+${event.countryCode}`} {event.phone}
              </p>
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground">Timestamp</label>
              <p className="text-sm text-muted-foreground">
                {new Date(event.createdOn).toLocaleString()}
              </p>
            </div>
          </div>

          {/* JSON Payload */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-semibold text-foreground">Full Payload</label>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopyPayload}
                className="gap-2"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    Copy Payload
                  </>
                )}
              </Button>
            </div>
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-xs text-foreground border border-border">
              {JSON.stringify(event.payload, null, 2)}
            </pre>
          </div>

          {/* Full Event JSON */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-semibold text-foreground">Full Event JSON</label>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopyFullEvent}
                className="gap-2"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    Copy Event
                  </>
                )}
              </Button>
            </div>
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-xs text-foreground border border-border">
              {JSON.stringify(
                {
                  id: event.id,
                  channelId: event.channelId,
                  workspaceId: event.workspaceId,
                  direction: event.direction,
                  eventType: event.eventType,
                  customerName: event.customerName,
                  customerId: event.customerId,
                  phone: event.phone,
                  countryCode: event.countryCode,
                  createdOn: event.createdOn,
                  payload: event.payload,
                },
                null,
                2
              )}
            </pre>
          </div>

          {/* Close Button */}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
