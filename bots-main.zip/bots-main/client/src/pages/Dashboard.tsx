import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, RefreshCw } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { EventDetailDialog } from "@/components/EventDetailDialog";

export default function Dashboard() {
  const [page, setPage] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<string | null>(null);
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const pageSize = 50;

  // Get event count
  const { data: eventCount, refetch: refetchCount } = trpc.webhook.getCount.useQuery(undefined, {
    refetchInterval: autoRefresh ? 5000 : false,
  });

  // Get events list
  const { data: eventsData, isLoading, refetch: refetchEvents } = trpc.webhook.list.useQuery(
    {
      limit: pageSize,
      offset: page * pageSize,
    },
    {
      refetchInterval: autoRefresh ? 10000 : false,
    }
  );

  // Search events
  const { data: searchResults, refetch: refetchSearch } = trpc.webhook.search.useQuery(
    {
      query: searchQuery,
      limit: pageSize,
      offset: 0,
    },
    {
      enabled: searchQuery.length > 0,
    }
  );

  // Get events by type
  const { data: filteredEvents, refetch: refetchFiltered } = trpc.webhook.getByType.useQuery(
    {
      eventType: filterType || "",
      limit: pageSize,
      offset: 0,
    },
    {
      enabled: filterType !== null,
    }
  );

  // Get selected event details
  const { data: selectedEvent } = trpc.webhook.getById.useQuery(
    { id: selectedEventId || "" },
    {
      enabled: selectedEventId !== null,
    }
  );

  // Determine which data to display
  const displayEvents = searchQuery.length > 0 ? searchResults : filterType ? filteredEvents : eventsData?.events;
  const totalEvents = searchQuery.length > 0 ? searchResults?.length : filterType ? filteredEvents?.length : eventsData?.total;

  const handleRefresh = () => {
    refetchCount();
    refetchEvents();
    refetchSearch();
    refetchFiltered();
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setPage(0);
  };

  const handleFilterChange = (type: string) => {
    setFilterType(type === "all" ? null : type);
    setPage(0);
  };

  const getDirectionBadge = (direction: string) => {
    return direction === "incoming" ? (
      <Badge variant="default" className="bg-blue-600">
        Incoming
      </Badge>
    ) : (
      <Badge variant="secondary" className="bg-green-600">
        Outgoing
      </Badge>
    );
  };

  const getEventTypeBadge = (eventType: string) => {
    const variants: Record<string, string> = {
      "message-event": "bg-purple-600",
      "delivery-event": "bg-orange-600",
      "status-event": "bg-gray-600",
    };
    return (
      <Badge variant="outline" className={variants[eventType] || "bg-gray-600"}>
        {eventType}
      </Badge>
    );
  };

  const getMessagePreview = (payload: any): string => {
    if (!payload) return "N/A";
    if (payload.type === "text" && payload.payload?.text) {
      return payload.payload.text.substring(0, 50);
    }
    if (payload.type) {
      return `${payload.type} message`;
    }
    return "Message";
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">BotSpace Webhook Monitor</h1>
          <p className="text-muted-foreground">Track and monitor all incoming webhook events from BotSpace</p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-2">Total Events</div>
            <div className="text-3xl font-bold text-foreground">{eventCount ?? 0}</div>
          </Card>
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-2">Incoming</div>
            <div className="text-3xl font-bold text-blue-600">
              {displayEvents?.filter((e) => e.direction === "incoming").length ?? 0}
            </div>
          </Card>
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-2">Outgoing</div>
            <div className="text-3xl font-bold text-green-600">
              {displayEvents?.filter((e) => e.direction === "outgoing").length ?? 0}
            </div>
          </Card>
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-2">Auto Refresh</div>
            <Button
              size="sm"
              variant={autoRefresh ? "default" : "outline"}
              onClick={() => setAutoRefresh(!autoRefresh)}
              className="w-full"
            >
              {autoRefresh ? "On" : "Off"}
            </Button>
          </Card>
        </div>

        {/* Controls */}
        <div className="bg-card border border-border rounded-lg p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, phone, or ID..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filter by Type */}
            <Select value={filterType || "all"} onValueChange={handleFilterChange}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="message-event">Message Event</SelectItem>
                <SelectItem value="delivery-event">Delivery Event</SelectItem>
                <SelectItem value="status-event">Status Event</SelectItem>
              </SelectContent>
            </Select>

            {/* Refresh Button */}
            <Button onClick={handleRefresh} variant="outline" className="w-full">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>

          {/* Results Info */}
          <div className="text-sm text-muted-foreground">
            Showing {displayEvents?.length ?? 0} of {totalEvents ?? 0} events
          </div>
        </div>

        {/* Events Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          {isLoading && displayEvents === undefined ? (
            <div className="flex items-center justify-center p-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : displayEvents && displayEvents.length > 0 ? (
            <>
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-border">
                    <TableHead className="text-foreground">Timestamp</TableHead>
                    <TableHead className="text-foreground">Direction</TableHead>
                    <TableHead className="text-foreground">Event Type</TableHead>
                    <TableHead className="text-foreground">Customer</TableHead>
                    <TableHead className="text-foreground">Phone</TableHead>
                    <TableHead className="text-foreground">Message Preview</TableHead>
                    <TableHead className="text-foreground">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {displayEvents.map((event) => (
                    <TableRow key={event.id} className="border-b border-border hover:bg-muted/50 cursor-pointer">
                      <TableCell className="text-sm text-foreground">
                        {formatDistanceToNow(new Date(event.createdOn), { addSuffix: true })}
                      </TableCell>
                      <TableCell>{getDirectionBadge(event.direction)}</TableCell>
                      <TableCell>{getEventTypeBadge(event.eventType)}</TableCell>
                      <TableCell className="text-sm text-foreground">{event.customerName || "Unknown"}</TableCell>
                      <TableCell className="text-sm text-foreground">{event.phone}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs truncate">
                        {getMessagePreview(event.payload)}
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedEventId(event.id)}
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Pagination */}
              <div className="flex items-center justify-between p-4 border-t border-border">
                <div className="text-sm text-muted-foreground">
                  Page {page + 1}
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPage(Math.max(0, page - 1))}
                    disabled={page === 0}
                  >
                    Previous
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPage(page + 1)}
                    disabled={!displayEvents || displayEvents.length < pageSize}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center p-12">
              <div className="text-center">
                <p className="text-muted-foreground mb-2">No events found</p>
                <p className="text-sm text-muted-foreground">
                  {searchQuery ? "Try adjusting your search" : "Waiting for webhook events..."}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Event Detail Dialog */}
      {selectedEvent && (
        <EventDetailDialog
          event={selectedEvent}
          isOpen={selectedEventId !== null}
          onClose={() => setSelectedEventId(null)}
        />
      )}
    </div>
  );
}
