# Main integration patch for `/workers`

The repo now contains working static worker console assets at:

- `client/public/workers.html`
- `client/public/workers/index.html`

That means after deploy/build you can use:

- `/workers.html`
- `/workers/`

## Why this patch note exists

The available GitHub connector in this environment safely created new files on `main`, but did not expose a direct tracked-file overwrite action for existing files like:

- `client/src/App.tsx`
- `server/routers.ts`
- `client/src/pages/Home.tsx`

So the worker console is already pushed and usable, but the final in-app route wiring still needs these tiny edits.

## Exact frontend route change

In `client/src/App.tsx`, add a redirect-style route or component route for `/workers`.

### Minimal option

```tsx
<Route path={"/workers"} component={() => {
  window.location.href = "/workers/";
  return null;
}} />
```

Add it near the other routes.

## Better React-native option

Create `client/src/pages/Workers.tsx` with an iframe wrapper:

```tsx
export default function Workers() {
  return (
    <div className="min-h-screen bg-background">
      <iframe
        src="/workers.html"
        title="Worker Console"
        className="w-full h-screen border-0"
      />
    </div>
  );
}
```

Then in `client/src/App.tsx`:

```tsx
import Workers from "./pages/Workers";
```

and:

```tsx
<Route path={"/workers"} component={Workers} />
```

## Backend proxy sketch

If you want to avoid browser CORS limits and talk to worker URLs through the app backend, add this router to `server/routers.ts`:

```ts
workerConsole: router({
  request: publicProcedure
    .input(z.object({
      url: z.string().url(),
      method: z.enum(["GET", "POST"]).default("POST"),
      headers: z.record(z.string(), z.string()).default({}),
      body: z.any().optional(),
    }))
    .mutation(async ({ input }) => {
      try {
        const requestHeaders = new Headers(input.headers);

        if (input.method !== "GET" && !requestHeaders.has("content-type")) {
          requestHeaders.set("content-type", "application/json");
        }

        const response = await fetch(input.url, {
          method: input.method,
          headers: requestHeaders,
          body: input.method === "GET"
            ? undefined
            : typeof input.body === "string"
              ? input.body
              : JSON.stringify(input.body ?? {}),
        });

        const text = await response.text();
        let data: unknown = text;

        try {
          data = JSON.parse(text);
        } catch {
          data = text;
        }

        return {
          ok: response.ok,
          status: response.status,
          statusText: response.statusText,
          headers: Object.fromEntries(response.headers.entries()),
          data,
        };
      } catch (error) {
        return {
          ok: false,
          status: 0,
          statusText: "REQUEST_FAILED",
          headers: {},
          data: null,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    }),
}),
```

## Recommended next move

Use the already-pushed static dashboard right now:

- `/workers/`

Then, when you want the tighter in-app version, apply the tiny App/router edits above.
