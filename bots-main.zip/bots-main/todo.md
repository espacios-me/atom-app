# BotSpace Webhook Dashboard - TODO

## Database & Schema
- [x] Create webhookEvents table schema with: id, channelId, workspaceId, direction, eventType, customer (name/id), phone, payload, createdOn
- [x] Generate and apply Drizzle migration SQL
- [x] Verify database connection and table creation

## Webhook Endpoint
- [x] Create /api/webhook POST endpoint via tRPC
- [x] Implement BotSpace payload validation (incoming/outgoing/delivery event types)
- [x] Parse and extract event data from BotSpace payload structure
- [x] Store validated events to database
- [x] Forward events to Guilds CRM webhook endpoint
- [x] Add retry logic for failed Guilds CRM requests
- [x] Return 200 OK response for valid payloads
- [x] Return 400/401 for invalid/unauthorized requests
- [x] Add error handling and logging

## Dashboard UI
- [x] Create Dashboard page component with layout
- [x] Build events table with columns: timestamp, direction, event type, customer name, phone, message preview
- [x] Implement table sorting by timestamp and other columns
- [x] Add pagination or infinite scroll for large datasets
- [x] Display real-time event counter (total events captured)
- [x] Show event type breakdown stats (incoming/outgoing/delivery counts)

## Event Filtering & Search
- [x] Implement filter by event type (incoming/outgoing/delivery)
- [x] Implement search by customer name
- [x] Implement search by phone number
- [x] Implement search by message content
- [x] Add filter UI with clear/reset functionality
- [x] Ensure filters work together (AND logic)

## Event Detail View
- [x] Create event detail modal/page showing full JSON payload
- [x] Add syntax highlighting for JSON display
- [x] Add copy-to-clipboard functionality for payload
- [x] Make detail view accessible from table row click

## Real-time Updates
- [x] Set up polling or WebSocket for real-time event counter updates
- [x] Update event table with new events without full page refresh
- [x] Implement auto-refresh of statistics

## Security & Configuration
- [x] Store BotSpace API key in environment variables (BOTSPACE_API_KEY)
- [x] Store Guilds CRM webhook URL in environment variables (GUILDS_CRM_WEBHOOK_URL)
- [x] Validate webhook requests using API key
- [x] Add webhook signature verification if BotSpace provides it (optional - implement when BotSpace provides signature header)
- [x] Document environment setup in README
- [x] Add request/response logging for debugging

## Testing
- [x] Write vitest tests for webhook endpoint validation
- [x] Write vitest tests for event storage logic
- [x] Write vitest tests for filtering/search logic
- [x] Test with sample BotSpace payloads

## Git & Deployment
- [x] Initialize Git repository
- [x] Create .gitignore for node_modules, .env, dist, etc.
- [x] Create comprehensive README with setup instructions
- [x] Document environment variables needed for production
- [x] Add deployment guide for Guilds CRM

## Frontend Navigation
- [x] Add Dashboard route to App.tsx
- [x] Create Dashboard page component with table and filters
- [x] Create EventDetailDialog component for JSON viewing
- [x] Update Home page with link to Dashboard
- [x] Add breadcrumbs or navigation context

## Completed
- [x] Database schema created with webhookEvents table
- [x] Database migration applied successfully
- [x] Database helper functions for CRUD operations
- [x] Webhook tRPC procedures (receive, list, getById, getCount, getByType, search)
- [x] Dashboard page with events table and statistics
- [x] EventDetailDialog component with JSON syntax highlighting
- [x] App.tsx routing updated with Dashboard route
