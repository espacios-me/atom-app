import { describe, it, expect, vi, beforeEach } from "vitest";
import axios from "axios";
import { forwardToGuildsCRM } from "./webhookForwarder";

vi.mock("axios");
const mockedAxios = vi.mocked(axios);

describe("webhookForwarder", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  const mockPayload = {
    id: "test-event-123",
    channelId: "channel-456",
    workspaceId: "workspace-789",
    direction: "incoming" as const,
    event: "message-event",
    createdOn: "2026-03-28T07:56:00Z",
    customer: {
      name: "John Doe",
      id: "customer-123",
    },
    phone: {
      countryCode: "1",
      phone: "5551234567",
    },
    payload: {
      type: "text",
      payload: {
        text: "Hello, this is a test message",
      },
    },
  };

  it("should successfully forward webhook to Guilds CRM", async () => {
    mockedAxios.post.mockResolvedValueOnce({
      status: 200,
      data: { success: true },
    });

    const result = await forwardToGuildsCRM(mockPayload);

    expect(result.success).toBe(true);
    expect(result.statusCode).toBe(200);
    expect(result.retries).toBe(0);
  });

  it("should include API key in headers when configured", async () => {
    mockedAxios.post.mockResolvedValueOnce({
      status: 200,
      data: { success: true },
    });

    await forwardToGuildsCRM(mockPayload);

    const callArgs = mockedAxios.post.mock.calls[0];
    const headers = callArgs[2]?.headers;

    expect(headers).toHaveProperty("x-api-key");
    expect(headers).toHaveProperty("Content-Type", "application/json");
  });

  it("should transform BotSpace payload correctly", async () => {
    mockedAxios.post.mockResolvedValueOnce({
      status: 200,
      data: { success: true },
    });

    await forwardToGuildsCRM(mockPayload);

    const callArgs = mockedAxios.post.mock.calls[0];
    const transformedPayload = callArgs[1];

    expect(transformedPayload).toMatchObject({
      eventId: "test-event-123",
      channelId: "channel-456",
      workspaceId: "workspace-789",
      direction: "incoming",
      eventType: "message-event",
      customerName: "John Doe",
      customerId: "customer-123",
      phone: "5551234567",
      countryCode: "1",
      messageType: "text",
      messageContent: "Hello, this is a test message",
    });
  });

  it("should handle network errors gracefully", async () => {
    mockedAxios.post.mockRejectedValue(new Error("Network timeout"));

    const result = await forwardToGuildsCRM(mockPayload);

    expect(result.success).toBe(false);
    expect(result.error).toContain("Network timeout");
  }, { timeout: 15000 });
});
