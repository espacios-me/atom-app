import axios from "axios";

const GUILDS_CRM_WEBHOOK_URL = process.env.GUILDS_CRM_WEBHOOK_URL;
const GUILDS_CRM_API_KEY = process.env.GUILDS_CRM_API_KEY;
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

interface WebhookPayload {
  id: string;
  channelId: string;
  workspaceId: string;
  direction: string;
  event: string;
  createdOn: string;
  customer?: {
    name?: string;
    id?: string;
  };
  phone?: {
    countryCode?: string;
    phone: string;
  };
  payload: any;
}

interface ForwardingResult {
  success: boolean;
  statusCode?: number;
  error?: string;
  retries?: number;
}

/**
 * Transform BotSpace webhook payload to Guilds CRM format
 */
function transformPayload(botspacePayload: WebhookPayload): Record<string, any> {
  const messageContent = botspacePayload.payload?.payload?.text || "";
  const messageType = botspacePayload.payload?.type || "message";

  return {
    eventId: botspacePayload.id,
    channelId: botspacePayload.channelId,
    workspaceId: botspacePayload.workspaceId,
    direction: botspacePayload.direction,
    eventType: botspacePayload.event,
    timestamp: botspacePayload.createdOn,
    customerName: botspacePayload.customer?.name || null,
    customerId: botspacePayload.customer?.id || null,
    phone: botspacePayload.phone?.phone || null,
    countryCode: botspacePayload.phone?.countryCode || null,
    messageType,
    messageContent,
    originalPayload: botspacePayload.payload,
  };
}

/**
 * Forward webhook event to Guilds CRM with retry logic
 */
export async function forwardToGuildsCRM(
  payload: WebhookPayload,
  retryCount: number = 0
): Promise<ForwardingResult> {
  if (!GUILDS_CRM_WEBHOOK_URL) {
    console.warn("[Webhook Forwarder] GUILDS_CRM_WEBHOOK_URL not configured");
    return { success: true, error: "Forwarding not configured" };
  }

  try {
    const transformedPayload = transformPayload(payload);

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (GUILDS_CRM_API_KEY) {
      headers["x-api-key"] = GUILDS_CRM_API_KEY;
    }

    console.log(`[Webhook Forwarder] Forwarding event ${payload.id} (attempt ${retryCount + 1})`);

    const response = await axios.post(GUILDS_CRM_WEBHOOK_URL, transformedPayload, {
      headers,
      timeout: 10000,
    });

    console.log(`[Webhook Forwarder] Success: ${payload.id}, status: ${response.status}`);

    return {
      success: true,
      statusCode: response.status,
      retries: retryCount,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`[Webhook Forwarder] Failed: ${payload.id}: ${errorMessage}`);

    if (retryCount < MAX_RETRIES) {
      const delayMs = RETRY_DELAY_MS * Math.pow(2, retryCount);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
      return forwardToGuildsCRM(payload, retryCount + 1);
    }

    return {
      success: false,
      error: errorMessage,
      retries: retryCount,
    };
  }
}
