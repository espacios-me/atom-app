import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createWebhookEvent, getWebhookEvents, getWebhookEventById, getWebhookEventCount, getWebhookEventsByType, searchWebhookEvents } from "./db";
import { forwardToGuildsCRM } from "./webhookForwarder";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  webhook: router({
    receive: publicProcedure
      .input(
        z.object({
          id: z.string(),
          channelId: z.string(),
          workspaceId: z.string(),
          direction: z.enum(["incoming", "outgoing"]),
          event: z.string(),
          createdOn: z.string(),
          customer: z.object({
            name: z.string().optional(),
            id: z.string().optional(),
          }).optional(),
          phone: z.object({
            countryCode: z.string().optional(),
            phone: z.string(),
          }).optional(),
          payload: z.any(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const event = await createWebhookEvent({
            id: input.id,
            channelId: input.channelId,
            workspaceId: input.workspaceId,
            direction: input.direction,
            eventType: input.event,
            customerName: input.customer?.name || null,
            customerId: input.customer?.id || null,
            countryCode: input.phone?.countryCode || null,
            phone: input.phone?.phone || "",
            payload: input.payload,
            createdOn: new Date(input.createdOn),
          });

          forwardToGuildsCRM(input).catch((error) => {
            console.error("[Webhook] Async forward failed:", error);
          });

          return {
            success: true,
            eventId: event?.id,
            message: "Event captured and forwarded",
          };
        } catch (error) {
          console.error("[Webhook] Failed to process event:", error);
          return {
            success: false,
            error: "Failed to process webhook",
          };
        }
      }),

    list: publicProcedure
      .input(
        z.object({
          limit: z.number().max(100).default(50),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        const events = await getWebhookEvents(input.limit, input.offset);
        const total = await getWebhookEventCount();
        return { events, total };
      }),

    getById: publicProcedure
      .input(z.object({ id: z.string() }))
      .query(async ({ input }) => {
        return await getWebhookEventById(input.id);
      }),

    getCount: publicProcedure.query(async () => {
      return await getWebhookEventCount();
    }),

    getByType: publicProcedure
      .input(
        z.object({
          eventType: z.string(),
          limit: z.number().max(100).default(50),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        const events = await getWebhookEventsByType(input.eventType, input.limit, input.offset);
        return events;
      }),

    search: publicProcedure
      .input(
        z.object({
          query: z.string(),
          limit: z.number().max(100).default(50),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        const events = await searchWebhookEvents(input.query, input.limit, input.offset);
        return events;
      }),
  }),
});

export type AppRouter = typeof appRouter;
