import { count, desc, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, webhookEvents, WebhookEvent, InsertWebhookEvent } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createWebhookEvent(event: InsertWebhookEvent): Promise<WebhookEvent | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create webhook event: database not available");
    return null;
  }

  try {
    await db.insert(webhookEvents).values(event);
    const created = await db.select().from(webhookEvents).where(eq(webhookEvents.id, event.id)).limit(1);
    return created.length > 0 ? created[0] : null;
  } catch (error) {
    console.error("[Database] Failed to create webhook event:", error);
    throw error;
  }
}

export async function getWebhookEvents(limit: number = 100, offset: number = 0) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get webhook events: database not available");
    return [];
  }

  try {
    const events = await db
      .select()
      .from(webhookEvents)
      .orderBy((t) => desc(t.createdOn))
      .limit(limit)
      .offset(offset);
    return events;
  } catch (error) {
    console.error("[Database] Failed to get webhook events:", error);
    return [];
  }
}

export async function getWebhookEventById(id: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get webhook event: database not available");
    return undefined;
  }

  try {
    const result = await db.select().from(webhookEvents).where(eq(webhookEvents.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get webhook event:", error);
    return undefined;
  }
}

export async function getWebhookEventCount() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get webhook event count: database not available");
    return 0;
  }

  try {
    const result = await db.select({ count: count() }).from(webhookEvents);
    return result[0]?.count ?? 0;
  } catch (error) {
    console.error("[Database] Failed to get webhook event count:", error);
    return 0;
  }
}

export async function getWebhookEventsByType(eventType: string, limit: number = 100, offset: number = 0) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get webhook events: database not available");
    return [];
  }

  try {
    const events = await db
      .select()
      .from(webhookEvents)
      .where(eq(webhookEvents.eventType, eventType))
      .orderBy((t) => desc(t.createdOn))
      .limit(limit)
      .offset(offset);
    return events;
  } catch (error) {
    console.error("[Database] Failed to get webhook events by type:", error);
    return [];
  }
}

export async function searchWebhookEvents(
  query: string,
  limit: number = 100,
  offset: number = 0
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot search webhook events: database not available");
    return [];
  }

  try {
    const searchPattern = `%${query}%`;
    const events = await db
      .select()
      .from(webhookEvents)
      .where(
        or(
          like(webhookEvents.customerName, searchPattern),
          like(webhookEvents.phone, searchPattern),
          like(webhookEvents.customerId, searchPattern)
        )
      )
      .orderBy((t) => desc(t.createdOn))
      .limit(limit)
      .offset(offset);
    return events;
  } catch (error) {
    console.error("[Database] Failed to search webhook events:", error);
    return [];
  }
}
